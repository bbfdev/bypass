(()=>{window.addEventListener("message",e=>{e.source===window&&e.data&&chrome.runtime.sendMessage(e.data)});if(document.contentType==="text/html"){let e=document.createElement("script");e.src=chrome.runtime.getURL("app/detect_angular_for_extension_icon_bundle.js"),document.documentElement.appendChild(e),document.documentElement.removeChild(e)}})();
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
//# sourceMappingURL=ng_validate_bundle.js.map
